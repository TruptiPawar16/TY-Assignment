import sys

n=1
list = sys.argv[1:]
print "n = ",n
for i in range(len(list)):
   print list(n+i)%len(list)]
